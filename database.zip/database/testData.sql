# Connection: mysql_server_local
# Host: localhost
# Saved: 2005-03-25 09:17:30
# 
INSERT INTO Customer
 (username,
  password,
  address,
  city,
  state,
  zip,
  email,
  phone,
  creditCard)
VALUES 
 ('mark', 'gophillies', '2424 Panama St', 'Philadelphia', 'PA', '19103', 'mark@mail.com', '222-2222', '111-1111-1111');
 
INSERT INTO Orders
(orderId, orderDate, storeId, username, shipped)
VALUES
(null, '2001-01-01', 0, 'mark', 'Y');
   
INSERT INTO OrderItem
(orderId, itemId, qty)
VALUES
(0, 2, 2);

INSERT INTO OrderItem
(orderId, itemId, qty)
VALUES
(0, 5, 1);

INSERT INTO Cart
    (username, itemID, qty)
VALUES
    ('mark',
      2,
      2);     
