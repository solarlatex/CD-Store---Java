DROP TABLE Store;
DROP TABLE Customer;
DROP TABLE Item;
DROP TABLE Cart;
DROP TABLE Orders;
DROP TABLE OrderItem;

CREATE TABLE Store
 (storeID int NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  address varchar(100) NOT NULL,
  city varchar(50) NOT NULL,
  state varchar(2) NOT NULL,
  zip varchar(10) NOT NULL,
  phone varchar(13) NOT NULL,
  email varchar(50) NOT NULL,
  PRIMARY KEY(storeID) );
  
CREATE TABLE Customer
 (username varchar(15) NOT NULL,
  password varchar(8) NOT NULL,
  address varchar(100) NOT NULL,
  city varchar(50) NOT NULL,
  state varchar(2) NOT NULL,
  zip varchar(10) NOT NULL,
  phone varchar(13) NOT NULL,
  email varchar(50) NOT NULL,
  creditcard varchar(25),
  PRIMARY KEY(username) );  
  
CREATE TABLE Item
 (itemID int NOT NULL AUTO_INCREMENT,
  image varchar(50) NOT NULL, 
  description varchar(50) NOT NULL,
  price double NOT NULL,
  PRIMARY KEY(itemID) );
  
CREATE TABLE Cart
 (username varchar(10) NOT NULL,
  itemID int NOT NULL,
  qty int NOT NULL,
  CONSTRAINT primaryKeyCartItem PRIMARY KEY (username, itemID) );  
  
CREATE TABLE Orders
 (orderID int NOT NULL AUTO_INCREMENT,
  orderdate varchar(20) NOT NULL, 
  storeID int NOT NULL,
  username varchar(15) NOT NULL,
  shipped bool,
  PRIMARY KEY(orderID) );  
  
CREATE TABLE OrderItem
 (orderID int NOT NULL,
  itemID int NOT NULL,
  qty int NOT NULL,
  CONSTRAINT primaryKeyOrderItem PRIMARY KEY (orderID, itemID) );   

INSERT INTO Store
    (storeID, name, address, city, state, zip, phone, email)
VALUES
    (NULL,
     'Jambits',
     '123 Fake St.',
     'Danbury',
     'CT',
     '06810',
     '1-999-JAMBITS',
     'info@jambits.tv');
     
INSERT INTO Customer
    (username, password, name, address, city, state, zip, phone, email, creditcard)
VALUES
    ('happycamper',
     'password',
     '1234 Fake St.',
     'Danbury',
     'CT',
     '06810',
     '203-777-7878',
     'shinee@whitealbum.tv',
     '1234-5678-9123-4567 01/01');     
     
INSERT INTO Item
    (itemID, image, description, price)
VALUES
    (NULL,
     'img/let_it_be.jpg',
     'Beatles - Let it Be',
     '13.95');     
     
INSERT INTO Item
    (itemID, image, description, price)
VALUES
    (NULL,
     'img/sgt_peppers.jpg',
     'Beatles - Sgt. Peppers Lonely Hearts Club band',
     '14.95');   
     
INSERT INTO Cart
    (username, itemID, qty)
VALUES
    ('happycamper',
      1,
      1);        
      
INSERT INTO Orders
    (orderID, orderdate, storeID, username, shipped)
VALUES
     (NULL,
      '01/01/2001',
      1,
      'happycamper',
      'Y');          
      
INSERT INTO OrderItem
    (orderID, itemID, qty)
VALUES
     (1,
      1,
      1);         