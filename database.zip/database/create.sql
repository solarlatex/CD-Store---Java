CREATE TABLE Store
 (storeID int NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  address varchar(100) NOT NULL,
  city varchar(50) NOT NULL,
  state varchar(2) NOT NULL,
  zip varchar(10) NOT NULL,
  phone varchar(13) NOT NULL,
  email varchar(50) NOT NULL,
  PRIMARY KEY(storeID) );
  
CREATE TABLE Customer
 (username varchar(15) NOT NULL,
  password varchar(8) NOT NULL,
  address varchar(100) NOT NULL,
  city varchar(50) NOT NULL,
  state varchar(2) NOT NULL,
  zip varchar(10) NOT NULL,
  phone varchar(13) NOT NULL,
  email varchar(50) NOT NULL,
  creditcard varchar(25),
  PRIMARY KEY(username) );  
  
CREATE TABLE Item
 (itemID int NOT NULL AUTO_INCREMENT,
  image varchar(50) NOT NULL, 
  description varchar(50) NOT NULL,
  price double NOT NULL,
  PRIMARY KEY(itemID) );
  
CREATE TABLE Cart
 (username varchar(10) NOT NULL,
  itemID int NOT NULL,
  qty int NOT NULL,
  CONSTRAINT primaryKeyCartItem PRIMARY KEY (username, itemID) );  
  
CREATE TABLE Orders
 (orderID int NOT NULL AUTO_INCREMENT,
  orderdate varchar(20) NOT NULL, 
  storeID int NOT NULL,
  username varchar(15) NOT NULL,
  shipped bool,
  PRIMARY KEY(orderID) );  
  
CREATE TABLE OrderItem
 (orderID int NOT NULL,
  itemID int NOT NULL,
  qty int NOT NULL,
  CONSTRAINT primaryKeyOrderItem PRIMARY KEY (orderID, itemID) );   