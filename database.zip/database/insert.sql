INSERT INTO Store
    (storeID, name, address, city, state, zip, phone, email)
VALUES
    (NULL,
     'Jambits',
     '123 Fake St.',
     'Danbury',
     'CT',
     '06810',
     '1-999-JAMBITS',
     'info@jambits.tv');
     
INSERT INTO Customer
    (username, password, name, address, city, state, zip, phone, email, creditcard)
VALUES
    ('happycamper',
     'password',
     '1234 Fake St.',
     'Danbury',
     'CT',
     '06810',
     '203-777-7878',
     'shinee@whitealbum.tv',
     '1234-5678-9123-4567 01/01');     
     
INSERT INTO Item
    (itemID, image, description, price)
VALUES
    (NULL,
     'img/let_it_be.jpg',
     'Beatles - Let it Be',
     '13.95');     
     
INSERT INTO Cart
    (username, itemID, qty)
VALUES
    ('happycamper',
      1,
      1);        
      
INSERT INTO Orders
    (orderID, orderdate, storeID, username, shipped)
VALUES
     (NULL,
      '01/01/2001',
      1,
      'happycamper',
      1);          
      
INSERT INTO OrderItem
    (orderID, itemID, qty)
VALUES
     (1,
      1,
      1);         